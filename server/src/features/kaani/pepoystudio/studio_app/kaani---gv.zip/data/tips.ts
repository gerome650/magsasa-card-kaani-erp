
export const TIPS: string[] = [
  "Ang paglalagay ng mulch ay nakakatulong panatilihing mamasa-masa ang lupa at binabawasan ang pagtubo ng damo.",
  "Suriin ang ilalim ng mga dahon para sa mga peste na hindi agad nakikita.",
  "Ang tamang pagitan ng tanim ay nagbibigay ng sapat na sikat ng araw at hangin sa bawat halaman.",
  "I-rotate ang iyong mga pananim bawat season upang maiwasan ang pagdami ng sakit sa lupa.",
  "Ang pag-aani sa umaga ay nakakatulong na mapanatiling sariwa ang mga gulay.",
  "Gumamit ng compost upang mapabuti ang istraktura ng lupa at magdagdag ng nutrisyon.",
  "Tiyaking malinis ang iyong mga kagamitan sa bukid upang maiwasan ang pagkalat ng sakit.",
  "Ang maagang pagtukoy sa problema ng pananim ay susi sa epektibong pamamahala.",
  "Huwag mag-atubiling magtanong sa mga kapwa magsasaka o agrikultural na teknisyan para sa payo."
];
